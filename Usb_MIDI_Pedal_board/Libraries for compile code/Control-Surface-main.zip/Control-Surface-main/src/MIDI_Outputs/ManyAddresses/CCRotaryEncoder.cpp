#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include <MIDI_Outputs/ManyAddresses/CCRotaryEncoder.hpp>
#endif