#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
#include "DisplayInterfaceSSD1306.hpp"
#endif