#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
// #include "AudioVULEDs.hpp" // TODO: Mock Audio library
#endif