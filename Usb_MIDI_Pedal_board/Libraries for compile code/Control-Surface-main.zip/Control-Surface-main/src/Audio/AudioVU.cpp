#ifdef TEST_COMPILE_ALL_HEADERS_SEPARATELY
// #include "AudioVU.hpp" // TODO: Mock Audio library
#endif