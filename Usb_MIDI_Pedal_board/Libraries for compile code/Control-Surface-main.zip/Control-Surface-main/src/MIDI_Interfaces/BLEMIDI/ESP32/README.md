# ESP32 MIDI over Bluetooth Low Energy

Resources:

- https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/bluetooth/esp_gatts.html
- https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/bluetooth/esp_gatt_defs.html
- https://github.com/espressif/esp-idf/blob/v3.2/examples/bluetooth/gatt_server_service_table
- https://github.com/espressif/esp-idf/tree/v3.2/examples/bluetooth/gatt_security_server
- https://github.com/espressif/arduino-esp32/tree/master/libraries/BLE
